<header class="header post">
    <div class="container">
        <?php require_once('nav.php'); ?>
    </div>
</header>
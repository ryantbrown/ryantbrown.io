<div class="logo">
    <a href="/">
        <img src="/wp-content/themes/ryantbrown/img/logo.svg">
    </a>
</div>
<nav>
    <ul>
        <li><a href="/?s=">Blog</a></li>
        <li><a href="http://twitter.com/r_t_brown" class="symbol" target="_blank">&#xe286;</a></li>
        <li><a href="http://github.com/ryantbrown" class="symbol" target="_blank">&#xe237;</a></li>
        <li><a href="https://dribbble.com/ryantbrown" class="symbol" target="_blank">&#xe221;</a></li>
        <li><a href="mailto:me@ryantbrown.io" class="symbol">&#xe224;</a></li>
    </ul>
</nav>